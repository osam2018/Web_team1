<template>
    <el-main >
        <h2>3.</h2>
    </el-main>

</template>

<script lang="ts">
    import { Component, Vue } from 'vue-property-decorator';
    import HelloWorld from '@/components/HelloWorld.vue'; // @ is an alias to /src

    @Component({

    })
    export default class Home extends Vue {}
</script>

<style scoped>
    .about{
        line-height: 30px;
    }
</style>